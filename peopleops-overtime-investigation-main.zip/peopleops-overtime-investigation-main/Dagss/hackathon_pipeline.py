
from datetime import datetime
import sqlite3

from airflow.sdk import dag, task


@dag(
    dag_id="hackathon_sales_pipeline",
    start_date=datetime(2026, 1, 1),
    schedule=None,
    catchup=False,
    tags=["hackathon", "python", "sql"],
)
def hackathon_sales_pipeline():

    @task
    def extract_and_clean():
        sales = [
            ("INV001", "A", 100),
            ("INV002", "B", 200),
            ("INV003", "A", 150),
            ("INV004", "B", 300),
        ]

        cleaned_sales = [
            row for row in sales
            if row[2] > 0
        ]

        print("Python: Sales data cleaned")
        print(cleaned_sales)

        return cleaned_sales

    @task
    def run_sql_report(sales):
        conn = sqlite3.connect(":memory:")
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE sales (
                invoice_id TEXT,
                branch TEXT,
                amount INTEGER
            )
        """)

        cursor.executemany(
            "INSERT INTO sales VALUES (?, ?, ?)",
            sales
        )

        cursor.execute("""
            SELECT branch, SUM(amount)
            FROM sales
            GROUP BY branch
        """)

        report = cursor.fetchall()

        print("SQL Report: Total Sales by Branch")
        for row in report:
            print(row)

        conn.close()

    run_sql_report(extract_and_clean())


hackathon_sales_pipeline()
