﻿import sqlite3
import pandas as pd

DB_PATH = r"C:\Users\DELL\Desktop\airflow\hr_pipeline.db"

def transform_data():
    conn = sqlite3.connect(DB_PATH)
    print("Starting Data Transformation & Cleaning...")
    
    # 1. Clean Employees Table
    df_emp = pd.read_sql("SELECT * FROM raw_employees", conn)
    # Basic cleaning / renaming if needed
    df_emp.to_sql("dim_employees", conn, if_exists="replace", index=False)
    print("-> Created dim_employees")

    # 2. Clean Biometric Punches
    df_punches = pd.read_sql("SELECT * FROM raw_biometric_punches", conn)
    df_punches.to_sql("fct_biometric_punches", conn, if_exists="replace", index=False)
    print("-> Created fct_biometric_punches")

    # 3. Clean Overtime Requests
    df_ot = pd.read_sql("SELECT * FROM raw_overtime_requests", conn)
    df_ot.to_sql("fct_overtime_requests", conn, if_exists="replace", index=False)
    print("-> Created fct_overtime_requests")

    # 4. Clean Payroll Lines
    df_payroll = pd.read_sql("SELECT * FROM raw_payroll_lines", conn)
    df_payroll.to_sql("fct_payroll_lines", conn, if_exists="replace", index=False)
    print("-> Created fct_payroll_lines")

    conn.close()
    print("Transformation Stage Completed Successfully!")

if __name__ == "__main__":
    transform_data()
