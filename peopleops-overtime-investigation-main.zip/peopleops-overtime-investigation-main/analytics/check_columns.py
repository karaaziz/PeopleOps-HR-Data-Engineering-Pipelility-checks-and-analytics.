﻿import sqlite3
conn = sqlite3.connect(r"C:\Users\DELL\Desktop\airflow\hr_pipeline.db")
cursor = conn.cursor()
cursor.execute("PRAGMA table_info(dim_employees);")
print("dim_employees columns:", [col[1] for col in cursor.fetchall()])
cursor.execute("PRAGMA table_info(fct_overtime_requests);")
print("fct_overtime_requests columns:", [col[1] for col in cursor.fetchall()])
conn.close()
