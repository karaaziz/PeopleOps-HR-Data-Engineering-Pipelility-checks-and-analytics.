﻿import sqlite3
import pandas as pd

DB_PATH = r"C:\Users\DELL\Desktop\airflow\hr_pipeline.db"

def run_overtime_analysis():
    conn = sqlite3.connect(DB_PATH)
    print("Running Overtime Investigation Analysis...\n")
    
    # Query updated with correct column name: emp_id
    query = """
        SELECT 
            e.emp_id,
            e.full_name,
            e.department,
            COUNT(ot.request_id) as total_requests,
            SUM(ot.requested_hours) as total_requested_hours,
            SUM(ot.approved_hours) as total_approved_hours
        FROM fct_overtime_requests ot
        JOIN dim_employees e ON ot.emp_id = e.emp_id
        GROUP BY e.emp_id, e.full_name, e.department
        ORDER BY total_approved_hours DESC
        LIMIT 10;
    """
    
    df_result = pd.read_sql(query, conn)
    print("--- Top 10 Employees with Highest Approved Overtime ---")
    print(df_result.to_string(index=False))
    
    conn.close()
    print("\nAnalytics Stage Completed Successfully!")

if __name__ == "__main__":
    run_overtime_analysis()
