﻿import sqlite3
import pandas as pd
import os

DB_PATH = r"C:\Users\DELL\Desktop\airflow\hr_pipeline.db"
OUTPUT_DIR = r"C:\Users\DELL\Desktop\airflow\analytics\results"

os.makedirs(OUTPUT_DIR, exist_ok=True)

conn = sqlite3.connect(DB_PATH)

query = """
    SELECT 
        e.emp_id,
        UPPER(e.full_name) as employee_name,
        UPPER(e.department) as department,
        COUNT(ot.request_id) as total_requests,
        SUM(ot.requested_hours) as total_requested_hours,
        SUM(ot.approved_hours) as total_approved_hours
    FROM fct_overtime_requests ot
    JOIN dim_employees e ON ot.emp_id = e.emp_id
    GROUP BY e.emp_id, UPPER(e.full_name), UPPER(e.department)
    ORDER BY total_approved_hours DESC;
"""

df_result = pd.read_sql(query, conn)
output_file = os.path.join(OUTPUT_DIR, "top_overtime_analysis.csv")
df_result.to_csv(output_file, index=False)

conn.close()
print(f"Results successfully saved to: {output_file}")
