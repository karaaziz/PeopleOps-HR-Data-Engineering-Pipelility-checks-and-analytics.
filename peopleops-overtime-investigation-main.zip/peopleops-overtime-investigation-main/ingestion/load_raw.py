﻿import os
import glob
import hashlib
from datetime import datetime, timezone
import pandas as pd
import sqlite3

DB_PATH = r"C:\Users\DELL\Desktop\airflow\hr_pipeline.db"
DATA_DIR = r"C:\Users\DELL\Desktop\airflow\data"

def compute_row_hash(row):
    row_string = "".join(str(val) for val in row.values)
    return hashlib.md5(row_string.encode("utf-8")).hexdigest()

def ingest_data():
    conn = sqlite3.connect(DB_PATH)
    loaded_at = datetime.now(timezone.utc).isoformat()
    
    files = glob.glob(os.path.join(DATA_DIR, "*.*"))
    print(f"Total files found: {len(files)}")
    
    if len(files) == 0:
        print("Error: data folder mein koi file nahi mili! Pehle files 'data' folder mein rakhein.")
        conn.close()
        return

    for file_path in files:
        file_name = os.path.basename(file_path)
        table_name = "raw_" + os.path.splitext(file_name)[0]
        print(f"Processing {file_name} -> Table: {table_name}")
        
        if file_path.endswith(".csv"):
            df = pd.read_csv(file_path, dtype=str, low_memory=False)
        elif file_path.endswith(".json"):
            try:
                df = pd.read_json(file_path, dtype=str)
            except:
                df = pd.read_json(file_path, lines=True, dtype=str)
        else:
            continue
            
        initial_count = len(df)
        df["_source_file"] = file_name
        df["_loaded_at"] = loaded_at
        df["_row_hash"] = df.apply(compute_row_hash, axis=1)
        
        cursor = conn.cursor()
        cols_def = ", ".join([f'"{col}" TEXT' for col in df.columns])
        cursor.execute(f'CREATE TABLE IF NOT EXISTS "{table_name}" ({cols_def})')
        conn.commit()
        
        cursor.execute(f'SELECT _row_hash FROM "{table_name}"')
        existing_hashes = {row[0] for row in cursor.fetchall()}
        
        df_filtered = df[~df["_row_hash"].isin(existing_hashes)]
        if not df_filtered.empty:
            df_filtered.to_sql(table_name, conn, if_exists="append", index=False)
            
        cursor.execute(f'SELECT COUNT(*) FROM "{table_name}"')
        final_count = cursor.fetchone()[0]
        print(f"File: {file_name} | Raw Rows: {initial_count} | Loaded: {len(df_filtered)} | Total: {final_count}")
        print("-" * 50)
        
    conn.close()
    print("Stage 1 Ingestion Completed Successfully!")

if __name__ == "__main__":
    ingest_data()
