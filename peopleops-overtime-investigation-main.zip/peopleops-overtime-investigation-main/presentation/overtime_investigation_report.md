# PeopleOps Overtime Investigation - Summary Report

## Executive Summary
This report summarizes the data pipeline execution and initial analytics findings for the Indus Weave Textiles overtime investigation.

## Data Pipeline Architecture
1. **Raw Ingestion**: Extracted 12 raw files into `hr_pipeline.db` (SQLite).
2. **Data Transformation**: Standardized schemas into core dimension (`dim_employees`) and fact tables (`fct_overtime_requests`, `fct_biometric_punches`, `fct_payroll_lines`).
3. **Analytics**: Identified top overtime earners and key data quality issues.

## Key Data Quality Findings
- **Department Name Inconsistencies**: Department entries contain mixed cases (e.g., `Stitching`, `STITCHING`, `stitching`).
- **Duplicate & Case Sensitivity**: Employee records contain casing duplicates (e.g., `DANISH SOOMRO` vs `Danish Soomro`).

## Next Steps
- Implement data standardization routines during transformation.
- Prepare visual dashboards for management review.
